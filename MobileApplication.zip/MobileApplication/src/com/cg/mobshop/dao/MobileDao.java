package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileDao {		
	
	public List <Mobiles> getAllMobiles();
	
	public Mobiles getMobilesDetails(int mobid);
	
    public void addMobile(Mobiles mobile);
    
    public List<Mobiles> deleteMobile(int mobid );
    
    public int updateMobile(Mobiles mob);
    
}
