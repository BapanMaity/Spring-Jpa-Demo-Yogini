package com.cg.mobshop.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.mobshop.dto.Mobiles;
@Repository
@Transactional
public class MobileDaoImpl implements MobileDao {
	
	@PersistenceContext
	EntityManager manager;


	@Override
	public List<Mobiles> getAllMobiles() {
		
		String str="Select mobile from Mobiles mobile";
		TypedQuery<Mobiles> query=manager.createQuery(str,Mobiles.class);
	    return query.getResultList();
		
		
	}


	@Override
	public void addMobile(Mobiles mobile) {
		manager.persist(mobile);
		manager.flush();
		
	}


	@Override
	public Mobiles getMobilesDetails(int mobid) {
	
		Mobiles mobile=manager.find(Mobiles.class, mobid);
		return mobile;
	}


	@Override
	public int updateMobile(Mobiles mob) {
		
	    	manager.merge(mob);
	    	return mob.getMobileId();
	
	}


	@Override
	public List<Mobiles> deleteMobile(int mobid) {
		Mobiles mobile =getMobilesDetails(mobid);
		manager.remove(mobile);
		return getAllMobiles();
	}

}
