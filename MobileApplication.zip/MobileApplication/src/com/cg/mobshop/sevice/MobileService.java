package com.cg.mobshop.sevice;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileService {
	
	public List <Mobiles>getAllMobiles();
 public int updateMobile(Mobiles mob);
	public Mobiles getMobilesDetails(int mobid);
	public void addMobile(Mobiles mobile);
	public List<Mobiles> deleteMobile(int mobid);
}
