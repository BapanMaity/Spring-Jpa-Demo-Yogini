package com.cg.mobshop.sevice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mobshop.dao.MobileDao;
import com.cg.mobshop.dto.Mobiles;
@Service
@Transactional
public class MobileServiceImpl implements MobileService {

	@Autowired
	MobileDao dao;
	@Override
	public List<Mobiles> getAllMobiles() {
		
	return dao.getAllMobiles();
	}
	@Override
	public void addMobile(Mobiles mobile) {
		dao.addMobile(mobile);
		
	}
	@Override
	public Mobiles getMobilesDetails(int mobid) {
		
		return dao.getMobilesDetails(mobid);
	}
	@Override
	public int updateMobile(Mobiles mob) {
		
		return dao.updateMobile(mob);
	}
	@Override
	public List<Mobiles> deleteMobile(int mobid) {
		
		return dao.deleteMobile(mobid);
	}

	
}
